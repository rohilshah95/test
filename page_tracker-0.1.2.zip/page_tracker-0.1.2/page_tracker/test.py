import pageTracker
pageTracker.track_page()