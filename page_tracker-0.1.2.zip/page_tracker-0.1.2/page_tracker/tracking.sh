#!/usr/bin/env python2

import pageTracker
pageTracker.track_page()